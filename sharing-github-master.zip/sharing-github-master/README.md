#wake
X=int(input("givey")
